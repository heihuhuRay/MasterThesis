import numpy as np
import copy
def functionblah(x):

    #y=x[:]
    y=copy.deepcopy(x)
    y.append([1])
    return y    

x=[2,3]
print x
a=functionblah(x)
print x
print a
