
global SSH_Conection 
SSH_Conection= 1

import socket
import time
import threading
import ast
import numpy as np
from gripper20driver import *
from gripperActdriver import *

PI_IP = "169.254.234.160"
NAO_IP = "169.254.040.17"

UDP_PORT1 = 5005
UDP_PORT2 = 5006

UDP_IP1 = NAO_IP
UDP_IP2 = PI_IP

MESSAGE = "Hello, Nao! I am the PI :)"
MESSAGE2 = []

print "message:", MESSAGE2

sock1 = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock2 = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP        
sock2.bind((UDP_IP2, UDP_PORT2))

# Load fingure
f = []
f.append(Fingure('sensordata/20sensor.v2.F0',4,0x4b))
f.append(Fingure('sensordata/20sensor.v2.F1',5,0x48))
f.append(Fingure('sensordata/20sensor.v2.F2',6,0x4a))
f.append(Fingure('sensordata/20sensor.v2.F3',7,0x49))

for i in range(4):
    f[i].loadData()
    
i=0
while True:
    i=i+1
    
    MESSAGESensors = []

    for i in range(4):
        f[i].readFingureCurvingSensor()

    for i in range(4):
        f[i].readFingurePressureSensor()

    for i in range(4):
        f[i].CalcFingureCurvingEstimation()
        
    airPressureSensorRead = ADCdriver.readadc(0)
    
    for i in range(4):
            MESSAGESensors.append([f[i].CNewRead, f[i].PNewRead[:]])
    
    MESSAGESensors.append(airPressureSensorRead)

    #print MESSAGESensors
    
    sock1.sendto(str(MESSAGESensors), (UDP_IP1, UDP_PORT1))
    
    data, addr = sock2.recvfrom(1024) # buffer size is 1024 bytes
    #print "received message:", data
    #print ast.literal_eval(data)
    print data
    airflow,grValve,evacuationValve = ast.literal_eval(data)
    #print "airflow: ",airflow,"\t grValve: ",grValve,"\t evacuationValve: ",evacuationValve  
    #time.sleep(1)
    pumpOn(airflow)
    grip(grValve)
    relise(evacuationValve)
    
