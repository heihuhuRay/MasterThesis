global SSH_Conection 
SSH_Conection= 1

import numpy as np
import time 
from Tkinter import*
#Import the ADS1x15 module.
if SSH_Conection==0:
    import matplotlib.pyplot  as plt 
from gripper20driver import *
from gripperActdriver import *



if SSH_Conection==0:
    animation = Tk()
    canvas = Canvas(animation, width= 400 , height=400)
    canvas.config(background="black")
    canvas.pack()

orgX = 200
orgY = 200
senL = 200
L1 = 2*senL
L2 = 0.2*senL


f = []
f.append(Fingure('F1',4,0x4b))
f.append(Fingure('F2',5,0x48))
f.append(Fingure('F3',6,0x4a))
f.append(Fingure('F4',7,0x49))


#calib = True # False # True
calib = False # False # True

 # line length is 200

if calib == True:
    
    f[0].fingureCalibrate()
    f[1].fingureCalibrate()
    f[2].fingureCalibrate()
    f[3].fingureCalibrate()


for i in range(4):
    f[i].loadData()

for i in range(4):
    print "Fingure ",i," data file: \n",f[i].datafile,"\n"



for i in range(4): 
    print "f",i," minC  and maxC: ", f[i].minC , f[i].maxC
    print "f",i," minP: ", f[i].minP
    print "f",i," maxP: ", f[i].maxP
    print "f",i," slope: ", f[i].slope
        
    
#all_adc_ch_0 = np.array([])
#all_ps_F1 =np.array([])

startT=time.time()
myT = startT
endT = 5.0 # sec
#while True:

airflow=0

ctr_T = 0
while((myT-startT)<endT):
    myT=time.time()
    ctr_T = ctr_T+1

    for i in range(4):
        f[i].readFingureCurvingSensor()

    for i in range(4):
        f[i].readFingurePressureSensor()

    pumpOn(0)
    grip(0)
    relise(0)
    

runtime = myT - startT
print "ctr_T: ", ctr_T
print "running time: ", runtime
print "loops per second: ", ctr_T/runtime



pumpOn(0)
grip(0)

time.sleep(1)
relise(1)
print "release ..."

time.sleep(1)
relise(0)

