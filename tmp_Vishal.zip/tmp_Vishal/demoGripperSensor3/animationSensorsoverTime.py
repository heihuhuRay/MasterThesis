"""
============
Oscilloscope
============

Emulates an oscilloscope.
"""
import numpy as np
from matplotlib.lines import Line2D
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from gripper20driver import *
import time 




f = []
f.append(Fingure('F1',4,0x4b))
f.append(Fingure('F2',5,0x48))
f.append(Fingure('F3',6,0x4a))
f.append(Fingure('F4',7,0x49))

for i in range(4):
    f[i].loadData()


for i in range(4):
    print "Fingure ",i," data file: \n",f[i].datafile,"\n"


for i in range(4): 
    print "f",i," minC  and maxC: ", f[i].minC , f[i].maxC
    print "f",i," minP: ", f[i].minP
    print "f",i," maxP: ", f[i].maxP
    print "f",i," slope: ", f[i].slope

class Scope(object):
    def __init__(self, ax, maxt=2, dt=0.02):
        self.ax = ax
        self.dt = dt
        self.maxt = maxt
        self.tdata = [0]
        self.ydata = [0]
        
        self.line = Line2D(self.tdata, self.ydata,linewidth=5,color='yellow')
        self.ax.add_line(self.line)
        self.ax.set_ylim(0.0, 4.0) # 0 to 5 volts
        self.ax.set_xlim(0, self.maxt)
        #self.ax.set_ylabel("Voltage",size='xx-large')
        self.ax.set_ylabel("Voltage",fontsize=50)
        self.ax.tick_params(axis='y', labelsize=30)
        self.ax.tick_params(axis='x', labelsize=1)
        #self.ax.set_facecolor("black")
        self.ax.patch.set_facecolor('black')




    def update(self, y):
        lastt = self.tdata[-1]
        if lastt > self.tdata[0] + self.maxt:  # reset the arrays
            self.tdata = [self.tdata[-1]]
            self.ydata = [self.ydata[-1]]
            self.ax.set_xlim(self.tdata[0], self.tdata[0] + self.maxt)
            self.ax.figure.canvas.draw()

        t = self.tdata[-1] + self.dt
        self.tdata.append(t)
        self.ydata.append(y[0])
        self.line.set_data(self.tdata, self.ydata)
        #print y[1]
        return self.line,


def emitter():
    'return a random value with probability p, else 0'
    while True:

        for i in range(4):
            f[i].readFingureCurvingSensor()

        #for i in range(4):
        f[0].readFingurePressureSensor()
        f[0].CalcFingureCurvingEstimation()
        xx = f[0].PNewRead[2] * 3.3 / 26500.0
        #xx = f[0].CNewRead * 3.3 / 1023 
        #xx = f[0].CNewEstim * 3.3 / 1023 
        #xx = ADCdriver.readadc(7)
        #print xx
        #print f[0].PNewRead[0],"\t",f[0].PNewRead[1],"\t",f[0].PNewRead[2],"\t",f[0].PNewRead[3]

        #for i in range(4):
        #    f[i].CalcFingureCurvingEstimation()

        #print f[3].PNewRead[3]
        #yield f[3].PNewRead[3]/10000.0

        # For air pressure sensor 
        #yield (xx-400.0)/10.0

        # For curving sensor 
        #yield (xx-500.0)/500.0

        # For touch sensors 
        #yield (xx-5000.0)/20000.0
        #yield (xx)/20000.0
        #yield (xx)/1000.0
        print f[0].PNewRead[2]
        yield xx,1


def emitter2():
    'return a random value with probability p, else 0'
    while True:

        for i in range(4):
            f[i].readFingureCurvingSensor()

        #for i in range(4):
        f[0].readFingurePressureSensor()
        f[0].CalcFingureCurvingEstimation()
        xx = f[0].PNewRead[2] * 3.3 / 26500.0
        #xx = f[0].CNewRead * 3.3 / 1023 
        #xx = f[0].CNewRead * 3.3 / 1023 
        
        #xx = ADCdriver.readadc(7)
        #print xx
        #print f[0].PNewRead[0],"\t",f[0].PNewRead[1],"\t",f[0].PNewRead[2],"\t",f[0].PNewRead[3]

        #for i in range(4):
        #    f[i].CalcFingureCurvingEstimation()

        #print f[3].PNewRead[3]
        #yield f[3].PNewRead[3]/10000.0

        # For air pressure sensor 
        #yield (xx-400.0)/10.0

        # For curving sensor 
        #yield (xx-500.0)/500.0

        # For touch sensors 
        #yield (xx-5000.0)/20000.0
        #yield (xx)/20000.0
        #yield (xx)/1000.0
        yield xx,1

        
fig, ax = plt.subplots()
scope = Scope(ax)

fig2, ax2 = plt.subplots()
scope2 = Scope(ax2)


scope2.ax.set_ylabel("Real sensor read",fontsize=30)
scope.ax.set_ylabel("Sensor estimation",fontsize=30)



# pass a generator in "emitter" to produce data for the update func
ani = animation.FuncAnimation(fig, scope.update, emitter, interval=100,
                              blit=True)

#ani2 = animation.FuncAnimation(fig2, scope2.update, emitter2, interval=100,blit=True)

plt.show()
