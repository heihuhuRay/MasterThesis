"""
============
Oscilloscope
============

Emulates an oscilloscope.
"""
import numpy as np
from matplotlib.lines import Line2D
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as mpatches

from gripper20driver import *
import time 

ExperimentDataSensors=[]

f = []
f.append(Fingure('sensordata/20sensor.v2.F0',4,0x4b))
f.append(Fingure('sensordata/20sensor.v2.F1',5,0x48))
f.append(Fingure('sensordata/20sensor.v2.F2',6,0x4a))
f.append(Fingure('sensordata/20sensor.v2.F3',7,0x49))

for i in range(4):
    f[i].loadData()

for i in range(4):
    print "Fingure ",i," data file: \n",f[i].datafile,"\n"

for i in range(4): 
    print "f",i," minC  and maxC: ", f[i].minC , f[i].maxC
    print "f",i," minP: ", f[i].minP
    print "f",i," maxP: ", f[i].maxP
    print "f",i," slope: ", f[i].slope

class Scope(object):
    def __init__(self, ax,maxt=5, dt=0.02,number_of_plots=1):
        self.ax = ax
        self.dt = dt
        self.maxt = maxt
        self.nbr_plots = number_of_plots
        self.tdata = [0]
        self.ydata = [0]
        self.ydata2 = [0]
        self.ydata3 = [0]
        self.ydata4 = [0]
        self.ydata5 = [0]
        self.ydata6 = [0]
        
        self.line = Line2D(self.tdata, self.ydata,linewidth=3,color='yellow')
        self.line2 = Line2D(self.tdata, self.ydata2,linewidth=3,color='green')

        self.line3 = Line2D(self.tdata, self.ydata3,linewidth=3,color='orange')
        self.line4 = Line2D(self.tdata, self.ydata4,linewidth=3,color='orange')
        self.line5 = Line2D(self.tdata, self.ydata5,linewidth=3,color='orange')
        self.line6 = Line2D(self.tdata, self.ydata6,linewidth=3,color='orange')

        self.ax.add_line(self.line)
        self.ax.add_line(self.line2)
        self.ax.add_line(self.line3)
        self.ax.add_line(self.line4)
        self.ax.add_line(self.line5)
        self.ax.add_line(self.line6)
        
        self.ax.set_ylim(0.0, 10.0) # 0 to 5 volts
        self.ax.set_xlim(0, self.maxt)
        #self.ax.set_ylabel("Voltage",size='xx-large')
        #self.ax.set_ylabel("Voltage",fontsize=50)
        self.ax.tick_params(axis='y', labelsize=30)
        self.ax.tick_params(axis='x', labelsize=1)
        #self.ax.set_facecolor("black")
        self.ax.patch.set_facecolor('black')




    def update(self, y):
        lastt = self.tdata[-1]
        if lastt > self.tdata[0] + self.maxt:  # reset the arrays
            self.tdata = [self.tdata[-1]]
            self.ydata = [self.ydata[-1]]
            self.ydata2 = [self.ydata2[-1]]
            self.ydata3 = [self.ydata3[-1]]
            self.ydata4 = [self.ydata4[-1]]
            self.ydata5 = [self.ydata5[-1]]
            self.ydata6 = [self.ydata6[-1]]
            self.ax.set_xlim(self.tdata[0], self.tdata[0] + self.maxt)
            self.ax.figure.canvas.draw()

        t = self.tdata[-1] + self.dt
        self.tdata.append(t)
        self.ydata.append(y[0])
        self.ydata2.append(y[1])
        self.ydata3.append(y[2])
        self.ydata4.append(y[3])
        self.ydata5.append(y[4])
        self.ydata6.append(y[5])
        self.line.set_data(self.tdata, self.ydata)
        self.line2.set_data(self.tdata, self.ydata2)
        self.line3.set_data(self.tdata, self.ydata3)
        self.line4.set_data(self.tdata, self.ydata4)
        self.line5.set_data(self.tdata, self.ydata5)
        self.line6.set_data(self.tdata, self.ydata6)

        return self.line,self.line2,self.line3,self.line4,self.line5,self.line6


def emitter():
    'return a random value with probability p, else 0'
    while True:

        for i in range(4):
            f[i].readFingureCurvingSensor()

        #for i in range(4):
        f[0].readFingurePressureSensor()
        f[0].CalcFingureCurvingEstimation()
        #xx = f[0].PNewRead[3] * 3.3 / 26500.0
        #xx = f[0].CNewRead * 3.3 / 1023 
        xx = f[0].CNewEstim * 6.0 / 1023 
        #xx = ADCdriver.readadc(7)
        #print xx
        #print f[0].PNewRead[0],"\t",f[0].PNewRead[1],"\t",f[0].PNewRead[2],"\t",f[0].PNewRead[3]

        #for i in range(4):
        #    f[i].CalcFingureCurvingEstimation()

        #print f[3].PNewRead[3]
        #yield f[3].PNewRead[3]/10000.0

        # For air pressure sensor 
        #yield (xx-400.0)/10.0

        # For curving sensor 
        #yield (xx-500.0)/500.0

        # For touch sensors 
        #yield (xx-5000.0)/20000.0
        #yield (xx)/20000.0
        #yield (xx)/1000.0
        yield xx,1


def emitter2():
    'return a random value with probability p, else 0'
    while True:

        for i in range(4):
            f[i].readFingureCurvingSensor()

        f_in= 2
        #for i in range(4):
        f[f_in].readFingurePressureSensor()
        f[f_in].CalcFingureCurvingEstimation()
        #xx = f[0].PNewRead[3] * 3.3 / 26500.0
        #xx = f[0].CNewRead * 3.3 / 1023 
        a  = f[f_in].CNewRead * 6.3 / 1023 
        b = f[f_in].CNewEstim * 6.3 / 1023

        #divisionfactor = 26500.0
        divisionfactor = 60000.0
        
        c = f[f_in].PNewRead[3] * 3.3 / divisionfactor
        d = f[f_in].PNewRead[2] * 3.3 / divisionfactor
        e = f[f_in].PNewRead[1] * 3.3 / divisionfactor
        g = f[f_in].PNewRead[0] * 3.3 / divisionfactor
        
        #xx = ADCdriver.readadc(7)
        #print xx
        #print f[0].PNewRead[0],"\t",f[0].PNewRead[1],"\t",f[0].PNewRead[2],"\t",f[0].PNewRead[3]

        #for i in range(4):
        #    f[i].CalcFingureCurvingEstimation()

        #print f[3].PNewRead[3]
        #yield f[3].PNewRead[3]/10000.0

        # For air pressure sensor 
        #yield (xx-400.0)/10.0

        # For curving sensor 
        #yield (xx-500.0)/500.0

        # For touch sensors 
        #yield (xx-5000.0)/20000.0
        #yield (xx)/20000.0
        #yield (xx)/1000.0
        #print f[0].CNewRead
        #time.sleep(0.1)
        #print f[f_in].PNewRead[0],'\t',f[f_in].PNewRead[1],'\t',f[f_in].PNewRead[2],'\t',f[f_in].PNewRead[3]
        print f[f_in].CNewRead


        
        ExperimentDataSensors.append([a,b,c,d,e,g])
        yield a-4,b-4,c+3,d+4,e+5,g+6


#fig, ax = plt.subplots()
#scope = Scope(ax)

fig2, ax2 = plt.subplots()
scope2 = Scope(ax2)


#scope2.ax.set_ylabel("Real sensor read",fontsize=30)
#scope.ax.set_ylabel("Sensor estimation",fontsize=30)
scope2.ax.tick_params(axis='y', labelsize=1)



# pass a generator in "emitter" to produce data for the update func
#ani = animation.FuncAnimation(fig, scope.update, emitter, interval=100,
#                              blit=True)

ani2 = animation.FuncAnimation(fig2, scope2.update, emitter2, interval=200,
                              blit=True)

green_patch = mpatches.Patch(color='green', label='Curving estimation')
yellow_patch = mpatches.Patch(color='yellow', label='Curving sensor reading')
orange_patch = mpatches.Patch(color='orange', label='Pressure sensors reading')
plt.legend(handles=[orange_patch,green_patch,yellow_patch],loc=2,fontsize=35)

plt.show()


np.save('ExperimentDataSensorsFinger.npy', ExperimentDataSensors)
