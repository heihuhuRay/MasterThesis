# gripper driver 
#!/usr/bin/python
import sys
sys.path.append("/home/pi/Adafruit-Raspberry-Pi-Python-Code/Adafruit_PWM_Servo_Driver")


from Adafruit_PWM_Servo_Driver import PWM
import time
import os
import RPi.GPIO as GPIO



# ===========================================================================
# Initialise the PWM device using the default address
pwm = PWM(0x40)
pwm.setPWMFreq(60)                        # Set frequency to 60 Hz

# ===========================================================================

# ===========================================================================

PWMmax = 4050
Airpmp= 15
AirOnValve = 11
AirOutValve = 7


def pumpOn(val):
    if val<=1.0:
            pwm.setPWM(Airpmp, 0, int(val*PWMmax))
    return

def grip(val):
    if val<=1.0:
            pwm.setPWM(AirOnValve, 0, int(val*PWMmax))
    return

def relise(val):
    if val<=1.0:
            pwm.setPWM(AirOutValve, 0, int(val*PWMmax))
    return

airflow = 0.4
