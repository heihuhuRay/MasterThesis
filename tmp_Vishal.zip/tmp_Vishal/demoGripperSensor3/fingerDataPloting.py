# finger data interpretation and ploting  
import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as sp
from sklearn import datasets, linear_model
import time 

data = np.load("F1_datacollection_.calib.npy")

print data


plt.figure()

plt.subplot()

for i in range(len(data)):
    #data[i][0]
    #data[i][1]
    plt.plot(data[i][1],data[i][0], 'ro')
    plt.title('curvingS4 vs pressureS44')
    plt.show()


    
