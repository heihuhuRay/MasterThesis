import socket
import time
import threading
import ast

PI_IP = "169.254.234.160"
NAO_IP = "169.254.040.17"

UDP_PORT1 = 5005
UDP_PORT2 = 5006


UDP_IP1 = NAO_IP
UDP_IP2 = PI_IP

MESSAGE = "Hello, Nao! I am the PI :)"
MESSAGE2 = [[1, 2, 3],[4, 5, 6]]

print "message:", MESSAGE2

sock1 = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP

sock2 = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
                     
sock2.bind((UDP_IP2, UDP_PORT2))

i=0
while True:
    i=i+1
    #sock1.sendto(MESSAGE+str(i), (UDP_IP1, UDP_PORT1))
    sock1.sendto(str(MESSAGE2), (UDP_IP1, UDP_PORT1))
    
    data, addr = sock2.recvfrom(1024) # buffer size is 1024 bytes
    print "received message:", data
    print ast.literal_eval(data)
    
    time.sleep(1)
    