import time 
from Tkinter import*

# values between 0 and 1
CS1 = 0.2
CS2 = 0.2
CS3 = 0.4
CS4 = 0.9


animation = Tk()
canvas = Canvas(animation, width= 800 , height=800)
canvas.pack()

# 1 Line Red
canvas.create_line(200, 0, 200, 200, fill="red", dash=(4, 4))
if CS1>0 and CS1<= 0.3:
        canvas.create_arc(200, 0, 600, 400, start=123, extent=57, width=1, style=ARC, outline="red", dash=(2, 2))
elif  CS1>0.3 and CS1<=0.6:
        canvas.create_arc(200, 50, 500, 350, start=103, extent=76, width=1, style=ARC, outline="red", dash=(4, 4))
elif  CS1>0.6 and CS1<0.9:
        canvas.create_arc(200, 137, 326, 263, start=0, extent=180, width=1, style=ARC, outline="red", dash=(4, 4))
else:
        canvas.create_arc(200, 137, 326, 263, start=0, extent=180, width=1, style=ARC, outline="red", dash=(4, 4))


#2th line Blue
canvas.create_line(200, 200, 400, 200, fill="red", dash=(4, 4))
if CS2 > 0 and CS2 <= 0.3:
    canvas.create_arc(0, 200, 400, 600, start=33, extent=57, width=1, style=ARC, outline="blue", dash=(2, 2))
elif CS2 > 0.3 and CS2 <= 0.6:
    canvas.create_arc(50, 200, 350, 500, start=13, extent=76, width=1, style=ARC, outline="blue", dash=(4, 4))
elif CS2 > 0.6 and CS2 <0.9:
    canvas.create_arc(100, 200, 300, 400, start=-25, extent=115, width=1, style=ARC, outline="blue",dash=(4, 4))
else:
    canvas.create_arc(137, 200, 263, 326, start=-90, extent=180, width=1, style=ARC, outline="blue",dash=(4, 4))

#3 line
canvas.create_line(200, 200, 200, 400,fill="Black")
if CS3 > 0 and CS3 <= 0.3:
    canvas.create_arc(200, 0, -200, 400, start=303, extent=57, width=1, style=ARC, outline="black")
elif CS3 > 0.3 and CS3 <= 0.6:
    canvas.create_arc(200, 50, -100, 350, start=284, extent=76, width=1, style=ARC, outline="black")
elif CS3 > 0.6 and CS3 < 0.9:
    canvas.create_arc(200, 100, 0, 300, start=245, extent=115, width=1, style=ARC, outline="black")
else:
    canvas.create_arc(200, 137, 63, 263, start=180, extent=180, width=1, style=ARC, outline="black")

#4th line Red
canvas.create_line(0, 200, 200, 200,fill="red")
if CS4 > 0 and CS4 <= 0.3:
    canvas.create_arc(0, -200, 400, 200, start=213, extent=57, width=1, style=ARC, outline="red")
elif CS4 > 0.3 and CS4 <= 0.6:
    canvas.create_arc(50, -100, 350, 200, start=194, extent=76, width=1, style=ARC, outline="red")
elif CS4 > 0.6 and CS4 < 0.9:
    canvas.create_arc(100, 0, 300, 200, start=155, extent=115, width=1, style=ARC, outline="red")
else:
    canvas.create_arc(137, 74, 263, 200, start=90, extent=180, width=1, style=ARC, outline="red")


# 1 Line Red
#canvas.create_line(200, 0, 200, 200 , fill="red", dash=(4, 4))
#canvas.create_arc(200,0, 600, 400, start=123, extent=57, width=1 , style=ARC , outline="red", dash=(2, 2))
#canvas.create_arc(200, 50, 500, 350, start=103, extent=76, width=1 , style=ARC , outline="red", dash=(4, 4))
#canvas.create_arc(200, 100, 400, 300, start=65, extent=115, width=1 , style=ARC ,outline="red", dash=(4, 4) )
#canvas.create_arc(200, 137, 326, 263, start=0, extent=180, width=1 , style=ARC ,outline="red", dash=(4, 4) )

#2th line Blue
#canvas.create_line(200, 200, 400, 200,fill="blue", dash=(4, 4))
#canvas.create_arc(0,200, 400, 600, start=33, extent=57, width=1 , style=ARC , outline="blue", dash=(2, 2))
#canvas.create_arc(50, 200, 350, 500, start=13, extent=76, width=1 , style=ARC , outline="blue", dash=(4, 4))
#canvas.create_arc(100, 200, 300, 400, start=-25, extent=115, width=1 , style=ARC ,outline="blue", dash=(4, 4) )
#canvas.create_arc(137, 200, 263, 326, start=-90, extent=180, width=1 , style=ARC ,outline="blue", dash=(4, 4) )

# 3th Line Green
#canvas.create_line(200, 200, 200, 400,fill="Black" )
#canvas.create_arc(200,0, -200, 400, start=303, extent=57, width=1, style=ARC, outline="black")
#canvas.create_arc(200, 50, -100, 350, start=284, extent=76, width=1, style=ARC, outline="black")
#canvas.create_arc(200, 100, 0, 300, start=245, extent=115, width=1 , style=ARC, outline="black" )
#canvas.create_arc(200, 137, 63, 263, start=180, extent=180, width=1 , style=ARC, outline="black")

#4th line Red
#canvas.create_line(0, 200, 200, 200,fill="red")
#canvas.create_arc(0,-200, 400, 200, start=213, extent=57, width=1 , style=ARC , outline="red")
#canvas.create_arc(50, 200, 350, 500, start=13, extent=76, width=1 , style=ARC , outline="red")
#canvas.create_arc(100, 200, 300, 400, start=-25, extent=115, width=1 , style=ARC ,outline="red")
#canvas.create_arc(137, 200, 263, 326, start=-90, extent=180, width=1 , style=ARC ,outline="red")

canvas.mainloop()
