# gripper velostat 20 sensors

import Adafruit_ADS1x15
import ADCdriver
import time 
import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as sp
from sklearn import datasets, linear_model

#####################################
class Fingure():

    
    def __init__(self, field1, field2, field3):
        self.name = field1
        self.curSensAdd = field2
        self.presSensAdd = field3
        self.datafile = []
        self.minC = +999999
        self.maxC = -999999
        self.minP = [+999999]*4
        self.maxP = [-999999]*4
        self.slope = [0]*4
        self.CNewRead = 0 # sensor reading 
        self.CLastRead = 0 # sensor reading 
        self.CNorm = 0 # normalized sensor value min- max 
        self.CNewEstim = 0 # extimated curving related value 
        self.CLastEstim = 0 # extimated curving related value 
        self.PNewRead = [0]*4
        self.PLastRead = [0]*4
        self.PNorm = [0]*4
        self.fin = Adafruit_ADS1x15.ADS1115(address=self.presSensAdd)
        self.NbrReadingCur = 0 
        self.NbrReadingPres = 0 

    def loadData(self):
        self.datafile = np.load(self.name+".calib.npy")
        [self.minC,self.maxC] = self.datafile[0][0:2]
        self.minP = self.datafile[1]
        self.maxP = self.datafile[2]
        self.slope = self.datafile[3]
        
    def readFingureCurvingSensor(self):
        self.CLastRead = self.CNewRead
        self.CNewRead = ADCdriver.readadc(self.curSensAdd)
        self.NbrReadingCur = self.NbrReadingCur+1

    def readFingurePressureSensor(self):
        for i in range(4):
            self.PLastRead[i] = self.PNewRead[i]
            self.PNewRead[i] = self.fin.read_adc(3-i, gain=ADSGAIN)
        self.NbrReadingPres = self.NbrReadingPres + 1 

    def CalcFingureCurvingEstimation(self):
        xx = +1
        self.CLastEstim = self.CNewEstim
        #print (1.0/self.slope[0])*(self.PNewRead[0]-self.PLastRead[0])
        #if (self.NbrReadingCur >= 2) and (self.NbrReadingPres >= 2):
        self.CNewEstim = self.CNewRead+\
                          (xx/self.slope[0])*(self.PNewRead[0]-self.PLastRead[0])+\
                          (xx/self.slope[1])*(self.PNewRead[1]-self.PLastRead[1])+\
                          (xx/self.slope[2])*(self.PNewRead[2]-self.PLastRead[2])+\
                          (xx/self.slope[3])*(self.PNewRead[3]-self.PLastRead[3])
        
        #else:
        #    self.CNewEstim = self.CNewRead
        #    self.CLastEstim = self.CNewRead

        #self.CNewEstim = self.CNewRead

    def fingureCalibrate(self):
    # AddressPS: 0x48 0x49 0x4a 0x4b
    # AddressCS: ch4:4 ch5:5 ch6:6 ch7:7
    # FingureIndex this is required to know the adresse of the analoge port

        
        #minadcCh = +999999
        #maxadcCh = -999999
        #minPSF = [+999999]*4
        #maxPSF = [-999999]*4
        #slope = [0]*4
        psF = 0

        self.fin = Adafruit_ADS1x15.ADS1115(address=self.presSensAdd)


        #ii = 0
        for ii in range(4):
            
            all_psF = []
            all_CS = []
            

            # within a loop
            # reading sensors..
            print "Press prerssure sensor :",ii," with different forces."
            time.sleep(2)
            ctr = 0
            tor = 0
            maxtime = 10.0
            start_time = time.time()
            while (tor<maxtime):

                tor = time.time()-start_time
                #print "remaining time: ", (maxtime-tor)
                psF = self.fin.read_adc(3-ii, gain=ADSGAIN)
                CS = ADCdriver.readadc(self.curSensAdd)
                all_psF.append(psF)
                all_CS.append([CS])
                
                #if (CS<self.minC): self.minC=CS
                #if (CS>self.maxC): self.maxC=CS
                
                if (psF<self.minP[ii]): self.minP[ii]=psF
                if (psF>self.maxP[ii]): self.maxP[ii]=psF

            # Create linear regression object
            regr = linear_model.LinearRegression()
            #all_CS = np.array(all_CS.transpose().tolist())
            # Train the model using the training sets

            #print "all_psF: ",all_psF
            #print "all_CS: ", all_CS

            regr.fit(all_CS, all_psF)
            # Make predictions using the testing set
            ps_pred = regr.predict(all_CS)
            plt.plot(all_CS, ps_pred, color='blue', linewidth=3)
            #plt.show()

            plt.plot(all_CS,all_psF, 'ro')
            plt.title('curving Sensor vs pressure sensor')
            plt.show()
            ########################
            # Calculation of slope..
            ########################
            ind2 = len(all_CS)-1
            ind1 = 0

            [x2] = all_CS[ind2]
            [x1] = all_CS[ind1]

            y2 = ps_pred[ind2]
            y1 = ps_pred[ind1]

            self.slope[ii] = (y2-y1)/(x2-x1)
            
            print "slope:",self.slope[ii]    

            print "minPSF: ",self.minP[ii],"   maxPSF: ",self.maxP[ii]
            print "minadcCh: ",self.minC,"   maxadcCh: ",self.maxC
            time.sleep(5)



        print "calibration of curving sensors... "
        print "bend the curving sensor ... "
        

        ctr = 0
        start_time = time.time()
        tor = 0
        maxtime = 10.0
        while (tor<maxtime):
            
            CS = ADCdriver.readadc(self.curSensAdd)

            if (CS<self.minC): self.minC=CS
            if (CS>self.maxC): self.maxC=CS

            tor = time.time()-start_time
            #print "remaining time: ", maxtime-tor



        
        print "slope: ", self.slope
        print "minPSF: ",self.minP
        print "maxPSF: ",self.maxP
        print "minadcCh: ",self.minC,"   maxadcCh: ",self.maxC

        Newcalibrarion = [[self.minC, self.maxC, 0, 0],self.minP,self.maxP,self.slope]


        print"Do you want to save the new calibration?"
        yes = {'yes','y', 'ye'}
        no = {'no','n'}

        while True:

            choice = raw_input().lower()
            if choice in yes:
               np.save(self.name + '.calib', Newcalibrarion)
               break 
            elif choice in no:
               break
            else:
               print"Please respond with 'yes' or 'no'"
               

        return


    ##################################################
    

#####################################
global adcCh,psF1,psF2,psF3,psF4,\
       minadcCh,maxadcCh,\
       minPSF1,maxPSF1,\
       minPSF2,maxPSF2,\
       minPSF3,maxPSF3,\
       minPSF4,maxPSF4,\
       fing1Ps,fing2Ps,fing3Ps,fing4Ps

# pressure sensors on four fingures 
ADSGAIN = 1
fing1Ps = Adafruit_ADS1x15.ADS1115(address=0x4b)
fing3Ps = Adafruit_ADS1x15.ADS1115(address=0x4a)
fing2Ps = Adafruit_ADS1x15.ADS1115(address=0x48)
fing4Ps = Adafruit_ADS1x15.ADS1115(address=0x49)


# initiate vectors for storing the ADC reading
adcCh= [0]*4
psF1 = [0]*4 
psF3 = [0]*4
psF2 = [0]*4 
psF4 = [0]*4

# Initiate min and max with the first reading.
minadcCh = [+999999]*4
maxadcCh = [-999999]*4
minPSF1 = [+999999]*4
maxPSF1 = [-999999]*4
minPSF2 = [+999999]*4
maxPSF2 = [-999999]*4
minPSF3 = [+999999]*4
maxPSF3 = [-999999]*4
minPSF4 = [+999999]*4
maxPSF4 = [-999999]*4

def limitFun(inv,minv,maxv):
    if (inv<minv):
        inv=minv
    if (inv>maxv):
        inv=maxv
    return inv

def readCurvingSensors():
    adc=[0]*4
    adc[0]= ADCdriver.readadc(4)
    adc[1]= ADCdriver.readadc(5)
    adc[2]= ADCdriver.readadc(6)
    adc[3]= ADCdriver.readadc(7)
    return adc


def readPressureSensors():

    # Read the specified ADC channel using the previously set gain value.
    for i in range(4):
        psF1[i] = fing1Ps.read_adc(3-i, gain=ADSGAIN)
    for i in range(4):
        psF2[i] = fing2Ps.read_adc(3-i, gain=ADSGAIN)
    for i in range(4):
        psF3[i] = fing3Ps.read_adc(3-i, gain=ADSGAIN)
    for i in range(4):
        psF4[i] = fing4Ps.read_adc(3-i, gain=ADSGAIN)
    return psF1,psF2,psF3,psF4

##################################################
def fingureCalibrate(AddressPS,AddressCS,filename):
# AddressPS: 0x48 0x49 0x4a 0x4b
# AddressCS: ch4:4 ch5:5 ch6:6 ch7:7
# FingureIndex this is required to know the adresse of the analoge port
    minadcCh = +999999
    maxadcCh = -999999
    minPSF = [+999999]*4
    maxPSF = [-999999]*4
    slope = [0]*4
    psF = 0

    Fingure = Adafruit_ADS1x15.ADS1115(address=AddressPS)


    #ii = 0
    for ii in range(4):
        
        all_psF = []
        all_CS = []
        

        # within a loop
        # reading sensors..
        print "Press prerssure sensor :",ii," with different forces."
        time.sleep(2)
        ctr = 0
        tor = 0
        maxtime = 2.0
        start_time = time.time()
        while (tor<maxtime):

            tor = time.time()-start_time
            #print "remaining time: ", (maxtime-tor)
            psF = Fingure.read_adc(3-ii, gain=ADSGAIN)
            CS = ADCdriver.readadc(AddressCS)
            all_psF.append(psF)
            all_CS.append([CS])
            
            if (CS<minadcCh): minadcCh=CS
            if (CS>maxadcCh): maxadcCh=CS
            
            if (psF<minPSF[ii]): minPSF[ii]=psF
            if (psF>maxPSF[ii]): maxPSF[ii]=psF

        # Create linear regression object
        regr = linear_model.LinearRegression()
        #all_CS = np.array(all_CS.transpose().tolist())
        # Train the model using the training sets

        #print "all_psF: ",all_psF
        #print "all_CS: ", all_CS

        regr.fit(all_CS, all_psF)
        # Make predictions using the testing set
        ps_pred = regr.predict(all_CS)
        plt.plot(all_CS, ps_pred, color='blue', linewidth=3)
        #plt.show()

        plt.plot(all_CS,all_psF, 'ro')
        plt.title('curving Sensor vs pressure sensor')
        plt.show()
        ########################
        # Calculation of slope..
        ########################
        ind2 = len(all_CS)-1
        ind1 = 0

        [x2] = all_CS[ind2]
        [x1] = all_CS[ind1]

        y2 = ps_pred[ind2]
        y1 = ps_pred[ind1]

        slope[ii] = (y2-y1)/(x2-x1)
        
        print "slope:",slope[ii]    

        print "minPSF: ",minPSF[ii],"   maxPSF: ",maxPSF[ii]
        print "minadcCh: ",minadcCh,"   maxadcCh: ",maxadcCh
        time.sleep(5)



    print "calibration of curving sensors... "
    print "bend the curving sensor ... "
    

    ctr = 0
    start_time = time.time()
    tor = 0
    maxtime = 5.0
    while (tor<maxtime):
        
        CS = ADCdriver.readadc(AddressCS)

        if (CS<minadcCh): minadcCh=CS
        if (CS>maxadcCh): maxadcCh=CS

        tor = time.time()-start_time
        #print "remaining time: ", maxtime-tor



    
    print "slope: ", slope
    print "minPSF: ",minPSF
    print "maxPSF: ",maxPSF
    print "minadcCh: ",minadcCh,"   maxadcCh: ",maxadcCh

    Newcalibrarion = [[minadcCh, maxadcCh, 0, 0],minPSF,maxPSF,slope]


    print"Do you want to save the new calibration?"
    yes = {'yes','y', 'ye'}
    no = {'no','n'}

    while True:

        choice = raw_input().lower()
        if choice in yes:
           np.save(filename+'.calib', Newcalibrarion)
           break 
        elif choice in no:
           break
        else:
           print"Please respond with 'yes' or 'no'"
           

    return


##################################################
def minMaxAllCalibrate():

    print "calibration of curving sensors... "
    adcCh = readCurvingSensors()
    

    ctr = 0
    start_time = time.time()
    tor = 0
    maxtime = 20.0
    while (tor<maxtime):
        
        adcCh = readCurvingSensors()

        for i in range(4):
            if (adcCh[i]<minadcCh[i]): minadcCh[i]=adcCh[i]
            if (adcCh[i]>maxadcCh[i]): maxadcCh[i]=adcCh[i]
        tor = time.time()-start_time
        print "remaining time: ", maxtime-tor


    print "calibration of pressure sensors... "
    psF1,psF2,psF3,psF4 = readPressureSensors()

    ctr = 0
    start_time = time.time()
    tor = 0
    maxtime = 30.0
    while (tor<maxtime):
        
        psF1,psF2,psF3,psF4 = readPressureSensors()

        for i in range(4):
            if (psF1[i]<minPSF1[i]): minPSF1[i]=psF1[i]
            if (psF1[i]>maxPSF1[i]): maxPSF1[i]=psF1[i]

            if (psF2[i]<minPSF2[i]): minPSF2[i]=psF2[i]
            if (psF2[i]>maxPSF2[i]): maxPSF2[i]=psF2[i]

            if (psF3[i]<minPSF3[i]): minPSF3[i]=psF3[i]
            if (psF3[i]>maxPSF3[i]): maxPSF3[i]=psF3[i]

            if (psF4[i]<minPSF4[i]): minPSF4[i]=psF4[i]
            if (psF4[i]>maxPSF4[i]): maxPSF4[i]=psF4[i]


        tor = time.time()-start_time
        print "remaining time: ", maxtime-tor

    print "minadcCh:",minadcCh
    print "maxadcCh:",maxadcCh
        
    print "minPSF1:",minPSF1
    print "maxPSF1:",maxPSF1

    print "minPSF2:",minPSF2
    print "maxPSF2:",maxPSF2

    print "minPSF3:",minPSF3
    print "maxPSF3:",maxPSF3

    print "minPSF4:",minPSF4
    print "maxPSF4:",maxPSF4

    Newcalibrarion= [minadcCh,minadcCh,minPSF1,maxPSF1,minPSF2,maxPSF2,\
                  minPSF3,maxPSF3,minPSF4,maxPSF4]

    print"Do you want to save the new calibration?"


    yes = {'yes','y', 'ye'}
    no = {'no','n'}

    while True:

        choice = raw_input().lower()
        if choice in yes:
           np.save('gripper.calib', Newcalibrarion)
           break 
        elif choice in no:
           break
        else:
           print"Please respond with 'yes' or 'no'"
    
    return

    


