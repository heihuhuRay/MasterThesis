# finger data interpretation and ploting  
import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as sp
from sklearn import datasets, linear_model

#[[minadcCh, maxadcCh, 0, 0],minPSF,maxPSF,slope]

data = np.load("F1.calib.npy")

print data

print data[0][0]
print data[0][1]



