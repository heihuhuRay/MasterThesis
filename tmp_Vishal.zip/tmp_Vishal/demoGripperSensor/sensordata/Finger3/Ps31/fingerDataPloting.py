# finger data interpretation and ploting  
import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as sp
from sklearn import datasets, linear_model

curvingS = np.load("fingerdataMeasurment1.npy")
pressureS11 = np.load("fingerdataMeasurment2.npy")
print(len(curvingS))
print(len(pressureS11))



plt.figure()
plt.subplot()
plt.plot(curvingS,pressureS11, 'ro')
plt.title('curvingS3 vs pressureS31')


CS1 = []
for ii in range(len(curvingS)):
    CS1.append([curvingS[ii]])

# Create linear regression object
regr = linear_model.LinearRegression()

curvingS = np.array(curvingS.transpose().tolist())

print CS1
print pressureS11

# Train the model using the training sets
regr.fit(CS1, pressureS11)

# Make predictions using the testing set
ps_pred = regr.predict(CS1)

plt.plot(CS1, ps_pred, color='blue', linewidth=3)
plt.show()

########################
# Calculation of slope..
########################
ind2 = len(CS1)-1
ind1 = 0

[x2] = CS1[ind2]
[x1] = CS1[ind1]

y2 = ps_pred[ind2]
y1 = ps_pred[ind1]

slope = (y2-y1)/(x2-x1) 
print "slope:",slope

