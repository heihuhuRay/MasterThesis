# finger data interpretation and ploting  
import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as sp
from sklearn import datasets, linear_model

curvingS = np.load("fingerdataMeasurment1.npy")
pressureS = np.load("fingerdataMeasurment2.npy")
print(len(curvingS))

CS1 = []
pressureS11= pressureS[2::4]
for ii in range(len(curvingS)):
    CS1.append([curvingS[ii]])
##pressureS12= pressureS[1::4]
##pressureS13= pressureS[2::4]
##pressureS14= pressureS[3::4]
##
plt.figure()
plt.subplot()
plt.plot(curvingS,pressureS11, 'ro')
plt.title('curvingS vs pressureS11')

##plt.subplot()
##plt.plot(curvingS,pressureS12, 'ro')
##plt.title('curvingS vs pressureS12')
##

####plt.subplot(413)
####plt.plot(curvingS,pressureS13, 'ro')
####plt.title('curvingS vs pressureS13')
####
####
####plt.subplot(414)
####plt.plot(curvingS,pressureS14, 'ro')
####plt.title('curvingS vs pressureS14')

fl = sp.interp1d(curvingS, pressureS11,kind='linear')

xnew = np.linspace(min(curvingS), max(curvingS), 2)
plt.plot( xnew, fl(xnew))

# Create linear regression object
regr = linear_model.LinearRegression()

curvingS = np.array(curvingS.transpose().tolist())

print CS1
print pressureS11

# Train the model using the training sets
regr.fit(CS1, pressureS11)

# Make predictions using the testing set
ps_pred = regr.predict(CS1)

plt.plot(CS1, ps_pred, color='blue', linewidth=3)
plt.show()

########################
# Calculation of slope..
########################
ind2 = len(CS1)-1
ind1 = 0

[x2] = CS1[ind2]
[x1] = CS1[ind1]

y2 = ps_pred[ind2]
y1 = ps_pred[ind1]

slope = (y2-y1)/(x2-x1) 
print "slope:",slope

