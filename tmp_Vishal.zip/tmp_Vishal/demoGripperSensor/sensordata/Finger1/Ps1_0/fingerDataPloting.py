# finger data interpretation and ploting  
import numpy as np
import matplotlib.pyplot as plt


curvingS = np.load("fingerdataMeasurment1.npy")
pressureS = np.load("fingerdataMeasurment2.npy")
print(len(curvingS))

pressureS11= pressureS[0::4]
##pressureS12= pressureS[1::4]
##pressureS13= pressureS[2::4]
##pressureS14= pressureS[3::4]
##
plt.figure()
plt.subplot()
plt.plot(curvingS,pressureS11, 'ro')
plt.title('curvingS vs pressureS11')

##plt.subplot()
##plt.plot(curvingS,pressureS12, 'ro')
##plt.title('curvingS vs pressureS12')
##

####plt.subplot(413)
####plt.plot(curvingS,pressureS13, 'ro')
####plt.title('curvingS vs pressureS13')
####
####
####plt.subplot(414)
####plt.plot(curvingS,pressureS14, 'ro')
####plt.title('curvingS vs pressureS14')
plt.show()

