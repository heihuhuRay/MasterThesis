# gripper velostat 20 sensors

import Adafruit_ADS1x15
import ADCdriver
import time 
import numpy as np

global adcCh,psF1,psF2,psF3,psF4,\
       minadcCh,maxadcCh,\
       minPSF1,maxPSF1,\
       minPSF2,maxPSF2,\
       minPSF3,maxPSF3,\
       minPSF4,maxPSF4,\
       fing1Ps,fing2Ps,fing3Ps,fing4Ps

# pressure sensors on four fingures 
ADSGAIN = 1
fing1Ps = Adafruit_ADS1x15.ADS1115(address=0x4b)
fing3Ps = Adafruit_ADS1x15.ADS1115(address=0x4a)
fing2Ps = Adafruit_ADS1x15.ADS1115(address=0x48)
fing4Ps = Adafruit_ADS1x15.ADS1115(address=0x49)


# initiate vectors for storing the ADC reading
adcCh= [0]*4
psF1 = [0]*4 
psF3 = [0]*4
psF2 = [0]*4 
psF4 = [0]*4

# Initiate min and max with the first reading.
minadcCh = [+999999]*4
maxadcCh = [-999999]*4
minPSF1 = [+999999]*4
maxPSF1 = [-999999]*4
minPSF2 = [+999999]*4
maxPSF2 = [-999999]*4
minPSF3 = [+999999]*4
maxPSF3 = [-999999]*4
minPSF4 = [+999999]*4
maxPSF4 = [-999999]*4

def limitFun(inv,minv,maxv):
    if (inv<minv):
        inv=minv
    if (inv>maxv):
        inv=maxv
    return inv

def readCurvingSensors():
    adc=[0]*4
    adc[0]= ADCdriver.readadc(4)
    adc[1]= ADCdriver.readadc(5)
    adc[2]= ADCdriver.readadc(6)
    adc[3]= ADCdriver.readadc(7)
    return adc

def readPressureSensors():

    # Read the specified ADC channel using the previously set gain value.
    for i in range(4):
        psF1[i] = fing1Ps.read_adc(3-i, gain=ADSGAIN)
    for i in range(4):
        psF2[i] = fing2Ps.read_adc(3-i, gain=ADSGAIN)
    for i in range(4):
        psF3[i] = fing3Ps.read_adc(3-i, gain=ADSGAIN)
    for i in range(4):
        psF4[i] = fing4Ps.read_adc(3-i, gain=ADSGAIN)
    return psF1,psF2,psF3,psF4

def minMaxAllCalibrate():

    print "calibration of curving sensors... "
    adcCh = readCurvingSensors()
    

    ctr = 0
    start_time = time.time()
    tor = 0
    maxtime = 20.0
    while (tor<maxtime):
        
        adcCh = readCurvingSensors()

        for i in range(4):
            if (adcCh[i]<minadcCh[i]): minadcCh[i]=adcCh[i]
            if (adcCh[i]>maxadcCh[i]): maxadcCh[i]=adcCh[i]
        tor = time.time()-start_time
        print "remaining time: ", maxtime-tor


    print "calibration of pressure sensors... "
    psF1,psF2,psF3,psF4 = readPressureSensors()

    ctr = 0
    start_time = time.time()
    tor = 0
    maxtime = 30.0
    while (tor<maxtime):
        
        psF1,psF2,psF3,psF4 = readPressureSensors()

        for i in range(4):
            if (psF1[i]<minPSF1[i]): minPSF1[i]=psF1[i]
            if (psF1[i]>maxPSF1[i]): maxPSF1[i]=psF1[i]

            if (psF2[i]<minPSF2[i]): minPSF2[i]=psF2[i]
            if (psF2[i]>maxPSF2[i]): maxPSF2[i]=psF2[i]

            if (psF3[i]<minPSF3[i]): minPSF3[i]=psF3[i]
            if (psF3[i]>maxPSF3[i]): maxPSF3[i]=psF3[i]

            if (psF4[i]<minPSF4[i]): minPSF4[i]=psF4[i]
            if (psF4[i]>maxPSF4[i]): maxPSF4[i]=psF4[i]


        tor = time.time()-start_time
        print "remaining time: ", maxtime-tor

    print "minadcCh:",minadcCh
    print "maxadcCh:",maxadcCh
        
    print "minPSF1:",minPSF1
    print "maxPSF1:",maxPSF1

    print "minPSF2:",minPSF2
    print "maxPSF2:",maxPSF2

    print "minPSF3:",minPSF3
    print "maxPSF3:",maxPSF3

    print "minPSF4:",minPSF4
    print "maxPSF4:",maxPSF4

    Newcalibrarion= [minadcCh,minadcCh,minPSF1,maxPSF1,minPSF2,maxPSF2,\
                  minPSF3,maxPSF3,minPSF4,maxPSF4]

    print"Do you want to save the new calibration?"


    yes = {'yes','y', 'ye'}
    no = {'no','n'}

    while True:

        choice = raw_input().lower()
        if choice in yes:
           np.save('gripper.calib', Newcalibrarion)
           break 
        elif choice in no:
           break
        else:
           print"Please respond with 'yes' or 'no'"

    


    
    
    return

    


