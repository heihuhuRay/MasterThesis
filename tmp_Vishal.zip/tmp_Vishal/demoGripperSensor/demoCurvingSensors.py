import ADCdriver
import numpy as np
import time 
from Tkinter import*



adcCh= np.zeros(4)

animation = Tk()
canvas = Canvas(animation, width= 800 , height=800)
canvas.pack()

canvas.create_line(200, 0, 200, 200, fill="red",tag="sens1")
canvas.create_line(200, 200, 400, 200, fill="blue",tag="sens2")
canvas.create_line(200, 200, 200, 400,fill="Black",tag="sens3")
canvas.create_line(0, 200, 200, 200,fill="red",tag="sens4")


while True:
    canvas.update_idletasks()
    canvas.update()
    

    adcCh[0]= ADCdriver.readadc(4)
    adcCh[1]= ADCdriver.readadc(5)
    adcCh[2]= ADCdriver.readadc(6)
    adcCh[3]= ADCdriver.readadc(7)


    CS1 = (adcCh[0]-750.0)/200.0
    CS2 = (adcCh[1]-750.0)/200.0
    CS3 = (adcCh[2]-750.0)/200.0
    CS4 = (adcCh[3]-750.0)/200.0



    # 1 Line Red

    canvas.delete("sens1")
    canvas.delete("sens2")
    canvas.delete("sens3")
    canvas.delete("sens4")


    if CS1>0 and CS1<= 0.3:
            canvas.create_arc(200, 0, 600, 400, start=123, extent=57, width=1, style=ARC, outline="red",tag="sens1")
    elif  CS1>0.3 and CS1<=0.6:
            canvas.create_arc(200, 50, 500, 350, start=103, extent=76, width=1, style=ARC, outline="red",tag="sens1")
    elif  CS1>0.6 and CS1<0.9:
            canvas.create_arc(200, 137, 326, 263, start=0, extent=180, width=1, style=ARC, outline="red",tag="sens1")
    else:
            canvas.create_arc(200, 137, 326, 263, start=0, extent=180, width=1, style=ARC, outline="red",tag="sens1")


    #2th line Blue
    if CS2 > 0 and CS2 <= 0.3:
        canvas.create_arc(0, 200, 400, 600, start=33, extent=57, width=1, style=ARC, outline="blue",tag="sens2")
    elif CS2 > 0.3 and CS2 <= 0.6:
        canvas.create_arc(50, 200, 350, 500, start=13, extent=76, width=1, style=ARC, outline="blue",tag="sens2")
    elif CS2 > 0.6 and CS2 <0.9:
        canvas.create_arc(100, 200, 300, 400, start=-25, extent=115, width=1, style=ARC, outline="blue",tag="sens2")
    else:
        canvas.create_arc(137, 200, 263, 326, start=-90, extent=180, width=1, style=ARC, outline="blue",tag="sens2")

    #3 line
    if CS3 > 0 and CS3 <= 0.3:
        canvas.create_arc(200, 0, -200, 400, start=303, extent=57, width=1, style=ARC, outline="black",tag="sens3")
    elif CS3 > 0.3 and CS3 <= 0.6:
        canvas.create_arc(200, 50, -100, 350, start=284, extent=76, width=1, style=ARC, outline="black",tag="sens3")
    elif CS3 > 0.6 and CS3 < 0.9:
        canvas.create_arc(200, 100, 0, 300, start=245, extent=115, width=1, style=ARC, outline="black",tag="sens3")
    else:
        canvas.create_arc(200, 137, 63, 263, start=180, extent=180, width=1, style=ARC, outline="black",tag="sens3")

    #4th line Red
    if CS4 > 0 and CS4 <= 0.3:
        canvas.create_arc(0, -200, 400, 200, start=213, extent=57, width=1, style=ARC, outline="red",tag="sens4")
    elif CS4 > 0.3 and CS4 <= 0.6:
        canvas.create_arc(50, -100, 350, 200, start=194, extent=76, width=1, style=ARC, outline="red",tag="sens4")
    elif CS4 > 0.6 and CS4 < 0.9:
        canvas.create_arc(100, 0, 300, 200, start=155, extent=115, width=1, style=ARC, outline="red",tag="sens4")
    else:
        canvas.create_arc(137, 74, 263, 200, start=90, extent=180, width=1, style=ARC, outline="red",tag="sens4")


    

    print adcCh
