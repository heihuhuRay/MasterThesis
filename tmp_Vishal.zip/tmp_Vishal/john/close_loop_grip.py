#!/usr/bin/python

from Adafruit_PWM_Servo_Driver import PWM
import time
import os
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

SPICLK = 18
SPIMISO = 23
SPIMOSI = 24
SPICS = 25

clockpin = SPICLK
mosipin = SPIMOSI
misopin = SPIMISO
cspin = SPICS

# read SPI data from MCP3008 chip, 8 possible adc's (0 thru 7)
#def readadc(adcnum, clockpin, mosipin, misopin, cspin):
def readadc(adcnum):
        if ((adcnum > 7) or (adcnum < 0)):
                return -1
        GPIO.output(cspin, True)

        GPIO.output(clockpin, False)  # start clock low
        GPIO.output(cspin, False)     # bring CS low

        commandout = adcnum
        commandout |= 0x18  # start bit + single-ended bit
        commandout <<= 3    # we only need to send 5 bits here
        for i in range(5):
                if (commandout & 0x80):
                        GPIO.output(mosipin, True)
                else:
                        GPIO.output(mosipin, False)
                commandout <<= 1
                GPIO.output(clockpin, True)
                GPIO.output(clockpin, False)

        adcout = 0
        # read in one empty bit, one null bit and 10 ADC bits
        for i in range(12):
                GPIO.output(clockpin, True)
                GPIO.output(clockpin, False)
                adcout <<= 1
                if (GPIO.input(misopin)):
                        adcout |= 0x1

        GPIO.output(cspin, True)
        
        adcout >>= 1       # first bit is 'null' so drop it
        return adcout

# change these as desired - they're the pins connected from the
# SPI port on the ADC to the Cobbler

# set up the SPI interface pins
GPIO.setup(SPIMOSI, GPIO.OUT)
GPIO.setup(SPIMISO, GPIO.IN)
GPIO.setup(SPICLK, GPIO.OUT)
GPIO.setup(SPICS, GPIO.OUT)


# ===========================================================================
# Initialise the PWM device using the default address
pwm = PWM(0x40)
pwm.setPWMFreq(60)                        # Set frequency to 60 Hz


ctr = 0
start_time = time.time()
tor = 0

# ===========================================================================

PWMmax = 4050
Airpmp= 15
AirOnValve = 11
AirOutValve = 7



### test pump 
##pwm.setPWM(Airpmp, 0, PWMmax)
##time.sleep(2)
##pwm.setPWM(Airpmp, 0, 0)
##time.sleep(2)
##
### test valve 1 
##pwm.setPWM(AirOutValve, 0, PWMmax)
##time.sleep(2)
##pwm.setPWM(AirOutValve, 0, 0)
##time.sleep(2)
##
### test valve 2 
##pwm.setPWM(AirOnValve, 0, PWMmax)
##time.sleep(2)
##pwm.setPWM(AirOnValve, 0, 0) 



def pumpOn(val):
    if val<=1.0:
            pwm.setPWM(Airpmp, 0, int(val*PWMmax))
    return

def grip(val):
    if val<=1.0:
            pwm.setPWM(AirOnValve, 0, int(val*PWMmax))
    return

def relise(val):
    if val<=1.0:
            pwm.setPWM(AirOutValve, 0, int(val*PWMmax))
    return

# ===========================================================================
# main loop
# ===========================================================================

airflow = 0.99

while (tor<15.0):
    ctr = ctr +1

    PresSens = readadc(2)
    Fingure1 = readadc(4)
    Fingure2 = readadc(5)
    Fingure3 = readadc(6)
    Fingure4 = readadc(7)
    allFinguresAvr = (Fingure1+Fingure2+Fingure3+Fingure4)/4.0
    #print "pressur sensor read: ",PresSens

    print "fingures resistor average: ", allFinguresAvr

    pumpOn(airflow)
    grip(1)
    if allFinguresAvr>950:
        airflow=0
        pumpOn(airflow)
        break 
    else:
        airflow = airflow # +0.05

##    pumpOn(airflow)
##    grip(1)
##    if PresSens>207:
##        relise(1)
##    else:
##        relise(0)

    tor = time.time()-start_time
    print "ctr",ctr

pumpOn(0)
grip(0)

time.sleep(5)
relise(1)
print "release ..."

time.sleep(3)
relise(0)

