
import numpy as np
import time 
from Tkinter import*
# Import the ADS1x15 module.
from gripper20driver import *
import matplotlib.pyplot as plt


animation = Tk()
canvas = Canvas(animation, width= 400 , height=400)
canvas.config(background="black")
canvas.pack()

orgX = 200
orgY = 200
senL = 200
L1 = 2*senL
L2 = 0.2*senL

#calib = True # False # True
calib = False # False # True

# line length is 200

if calib == True:
    minMaxAllCalibrate()
else:
    [minadcCh,minadcCh,minPSF1,maxPSF1,minPSF2,maxPSF2,\
                  minPSF3,maxPSF3,minPSF4,maxPSF4]=np.load("gripper.calib.npy")


while True:
    canvas.update_idletasks()
    canvas.update()

    adcCh = readCurvingSensors()
    psF1_,psF2_,psF3_,psF4_ = readPressureSensors()


    plt.plot(psF1_[0],adcCh[0],'ro')
    #plt.plot([1,2,3,4], [1,4,9,16], 'ro')
    #plt.axis([0, 1, 0, 1])
    plt.pause(0.001)

    
    #print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*psF3))
    #print adcCh[0] 

    CS1 = (adcCh[0]-750.0)/200.0
    CS2 = (adcCh[1]-750.0)/200.0 
    CS3 = (adcCh[2]-750.0)/200.0
    CS4 = (adcCh[3]-750.0)/200.0

    for i in range(4):
        adcCh[i] = (adcCh[i]-minadcCh[i])/(maxadcCh[i]-minadcCh[i])
        psF1[i] = float(psF1_[i]-minPSF1[i])/(maxPSF1[i]-minPSF1[i])
        psF2[i] = float(psF2_[i]-minPSF2[i])/(maxPSF2[i]-minPSF2[i])
        psF3[i] = float(psF3_[i]-minPSF3[i])/(maxPSF3[i]-minPSF3[i])
        psF4[i] = float(psF4_[i]-minPSF4[i])/(maxPSF4[i]-minPSF4[i])
    
    CS1 = limitFun(CS1,0.01,1.0)
    CS2 = limitFun(CS2,0.01,1.0)
    CS3 = limitFun(CS3,0.01,1.0)
    CS4 = limitFun(CS4,0.01,1.0)

    ps11,ps12,ps13,ps14 = psF1
    ps21,ps22,ps23,ps24 = psF2
    ps31,ps32,ps33,ps34 = psF3
    ps41,ps42,ps43,ps44 = psF4

    ps11 = limitFun(ps11,0.0,1.0)
    ps12 = limitFun(ps12,0.0,1.0) 
    ps13 = limitFun(ps13,0.0,1.0) 
    ps14 = limitFun(ps14,0.0,1.0) 

    ps21 = limitFun(ps21,0.0,1.0)
    ps22 = limitFun(ps22,0.0,1.0) 
    ps23 = limitFun(ps23,0.0,1.0) 
    ps24 = limitFun(ps24,0.0,1.0)

    ps31 = limitFun(ps31,0.0,1.0)
    ps32 = limitFun(ps32,0.0,1.0) 
    ps33 = limitFun(ps33,0.0,1.0) 
    ps34 = limitFun(ps34,0.0,1.0) 

    ps41 = limitFun(ps41,0.0,1.0)
    ps42 = limitFun(ps42,0.0,1.0) 
    ps43 = limitFun(ps43,0.0,1.0) 
    ps44 = limitFun(ps44,0.0,1.0)


    ps11 = 1-ps11
    ps12 = 1-ps12 
    ps13 = 1-ps13 
    ps14 = 1-ps14

    ps21 = 1-ps21
    ps22 = 1-ps22 
    ps23 = 1-ps23 
    ps24 = 1-ps24

    ps41 = 1-ps41
    ps42 = 1-ps42 
    ps43 = 1-ps43 
    ps44 = 1-ps44

    ps31 = 1-ps31
    ps32 = 1-ps32 
    ps33 = 1-ps33 
    ps34 = 1-ps34




    #plt.show(block=False)
    #time.sleep(0.001)
    # if CS value is 0 the circle circumstance is infinity
    # if CS value is 1.0 the circle circumstance is 2*200 

    circumstance1 = L1/CS1
    circumstance2 = L1/CS2
    circumstance3 = L1/CS3
    circumstance4 = L1/CS4

    radius1 = circumstance1 / (2*np.pi)
    radius2 = circumstance2 / (2*np.pi)
    radius3 = circumstance3 / (2*np.pi)
    radius4 = circumstance4 / (2*np.pi)

    CirAngle1 = senL*2*180/circumstance1
    CirAngle2 = senL*2*180/circumstance2
    CirAngle3 = senL*2*180/circumstance3
    CirAngle4 = senL*2*180/circumstance4
    
    canvas.delete("sens1")
    canvas.delete("sens2")
    canvas.delete("sens3")
    canvas.delete("sens4")

    canvas.delete("ps11")
    canvas.delete("ps12")    
    canvas.delete("ps13")    
    canvas.delete("ps14")    
    canvas.delete("ps21")    
    canvas.delete("ps22") 
    canvas.delete("ps23")
    canvas.delete("ps24") 
    canvas.delete("ps31")
    canvas.delete("ps32")
    canvas.delete("ps33")
    canvas.delete("ps34")
    canvas.delete("ps41")
    canvas.delete("ps42")
    canvas.delete("ps43")
    canvas.delete("ps44")
    
    canvas.create_arc(orgX,orgY-radius1,orgX+2*radius1,orgY+radius1, start=180-CirAngle1, extent=CirAngle1, width=4, style=ARC, outline="red",tag="sens1")
    canvas.create_arc(orgX-radius2, orgY, orgX+radius2, orgY+2*radius2, start=90-CirAngle2, extent=CirAngle2, width=4, style=ARC, outline="blue",tag="sens2")
    canvas.create_arc(orgX-2*radius3, orgY-radius3, orgX,orgY+radius3, start=-CirAngle3, extent=CirAngle3, width=4, style=ARC, outline="green",tag="sens3")
    canvas.create_arc(orgX-radius4, orgY-2*radius4, orgX+radius4, orgY, start=-90-CirAngle4, extent=CirAngle4, width=4, style=ARC, outline="yellow",tag="sens4")
    
    canvas.create_line(orgX, orgY, orgX, orgY-senL, fill="white",tag="sens1ref")
    canvas.create_line(orgX, orgY, orgX+senL, orgY, fill="white",tag="sens2ref")
    canvas.create_line(orgX, orgY, orgX, orgY+senL,fill="white",tag="sens3ref")
    canvas.create_line(orgX, orgY, orgX-senL, orgY,fill="white",tag="sens4ref")

    xst = orgX+radius1
    yst = orgY
    xend = orgX+radius1*( 1-np.cos(np.radians(CirAngle1)))
    yend = orgY-radius1*    np.sin(np.radians(CirAngle1))
    xend2= xend + L2 * np.cos(np.radians(CirAngle1))
    yend2 = yend + L2 * np.sin(np.radians(CirAngle1))
    xend3= xend + ps11*L2 * np.cos(np.radians(CirAngle1))
    yend3 = yend + ps11*L2 * np.sin(np.radians(CirAngle1))
    #canvas.create_line(xst, yst, xend, yend, fill="white",tag="ps01")
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps11")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="red",tag="ps11")
    
    xend = orgX+radius1*( 1-np.cos(np.radians(0.8*CirAngle1)))
    yend = orgY-radius1*    np.sin(np.radians(0.8*CirAngle1))
    xend2= xend + L2 * np.cos(np.radians(0.8*CirAngle1))
    yend2 = yend + L2 * np.sin(np.radians(0.8*CirAngle1))
    xend3= xend + ps12*L2 * np.cos(np.radians(0.8*CirAngle1))
    yend3 = yend + ps12*L2 * np.sin(np.radians(0.8*CirAngle1))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps12")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="red",tag="ps12")

    xend = orgX+radius1*( 1-np.cos(np.radians(0.6*CirAngle1)))
    yend = orgY-radius1*    np.sin(np.radians(0.6*CirAngle1))
    xend2= xend + L2 * np.cos(np.radians(0.6*CirAngle1))
    yend2 = yend + L2 * np.sin(np.radians(0.6*CirAngle1))
    xend3= xend + ps13*L2 * np.cos(np.radians(0.6*CirAngle1))
    yend3 = yend + ps13*L2 * np.sin(np.radians(0.6*CirAngle1))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps13")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="red",tag="ps13")

    xend = orgX+radius1*( 1-np.cos(np.radians(0.4*CirAngle1)))
    yend = orgY-radius1*    np.sin(np.radians(0.4*CirAngle1))
    xend2= xend + L2 * np.cos(np.radians(0.4*CirAngle1))
    yend2 = yend + L2 * np.sin(np.radians(0.4*CirAngle1))
    xend3= xend + ps14*L2 * np.cos(np.radians(0.4*CirAngle1))
    yend3 = yend + ps14*L2 * np.sin(np.radians(0.4*CirAngle1))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps14")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="red",tag="ps14")


    xst = orgX
    yst = orgY+radius2
    xend = orgX+radius2*np.sin(np.radians(CirAngle2))
    yend = orgY+radius2*   (1- np.cos(np.radians(CirAngle2)))
    xend2= xend - L2 * np.cos(np.radians(90-CirAngle2))
    yend2 = yend + L2 * np.sin(np.radians(90-CirAngle2))
    xend3= xend - ps21*L2 * np.cos(np.radians(90-CirAngle2))
    yend3 = yend + ps21*L2 * np.sin(np.radians(90-CirAngle2))
    #canvas.create_line(xst, yst, xend, yend, fill="white",tag="ps21")
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps21")    
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="blue",tag="ps21")    

    xend = orgX+radius2*np.sin(np.radians(0.8*CirAngle2))
    yend = orgY+radius2*   (1- np.cos(np.radians(0.8*CirAngle2)))
    xend2= xend - L2 * np.cos(np.radians((90-0.8*CirAngle2)))
    yend2 = yend + L2 * np.sin(np.radians((90-0.8*CirAngle2)))
    xend3= xend - ps22*L2 * np.cos(np.radians((90-0.8*CirAngle2)))
    yend3 = yend + ps22*L2 * np.sin(np.radians((90-0.8*CirAngle2)))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps22")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="blue",tag="ps22")
    
    xend = orgX+radius2*np.sin(np.radians(0.6*CirAngle2))
    yend = orgY+radius2*   (1- np.cos(np.radians(0.6*CirAngle2)))
    xend2= xend - L2 * np.cos(np.radians((90-0.6*CirAngle2)))
    yend2 = yend + L2 * np.sin(np.radians((90-0.6*CirAngle2)))
    xend3= xend - ps23*L2 * np.cos(np.radians((90-0.6*CirAngle2)))
    yend3 = yend + ps23*L2 * np.sin(np.radians((90-0.6*CirAngle2)))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps23")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="blue",tag="ps23")

    xend = orgX+radius2*np.sin(np.radians(0.4*CirAngle2))
    yend = orgY+radius2*   (1- np.cos(np.radians(0.4*CirAngle2)))
    xend2= xend - L2 * np.cos(np.radians((90-0.4*CirAngle2)))
    yend2 = yend + L2 * np.sin(np.radians((90-0.4*CirAngle2)))
    xend3= xend - ps24*L2 * np.cos(np.radians((90-0.4*CirAngle2)))
    yend3 = yend + ps24*L2 * np.sin(np.radians((90-0.4*CirAngle2)))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps24")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="blue",tag="ps24")
    

    # orgX-2*radius3, orgY-radius3, orgX,orgY+radius3
    xst = orgX-radius3
    yst = orgY
    xend = orgX-radius3*(1-np.cos(np.radians(CirAngle3)))
    yend = orgY+radius3* np.sin(np.radians(CirAngle3))
    xend2= xend - L2 * np.cos(np.radians(-CirAngle3))
    yend2 = yend + L2 * np.sin(np.radians(-CirAngle3))
    xend3= xend - ps31*L2 * np.cos(np.radians(-CirAngle3))
    yend3 = yend + ps31*L2 * np.sin(np.radians(-CirAngle3))
    #canvas.create_line(xst, yst, xend, yend, width=4,fill="green",tag="ps31")
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps31")    
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="green",tag="ps31")    

    xend = orgX-radius3*(1-np.cos(np.radians(0.8*CirAngle3)))
    yend = orgY+radius3* np.sin(np.radians(0.8*CirAngle3))
    xend2= xend - L2 * np.cos(np.radians(-0.8*CirAngle3))
    yend2 = yend + L2 * np.sin(np.radians(-0.8*CirAngle3))
    xend3= xend - ps32*L2 * np.cos(np.radians(-0.8*CirAngle3))
    yend3 = yend + ps32*L2 * np.sin(np.radians(-0.8*CirAngle3))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps32")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="green",tag="ps32")
    
    xend = orgX-radius3*(1-np.cos(np.radians(0.6*CirAngle3)))
    yend = orgY+radius3* np.sin(np.radians(0.6*CirAngle3))
    xend2= xend - L2 * np.cos(np.radians(-0.6*CirAngle3))
    yend2 = yend + L2 * np.sin(np.radians(-0.6*CirAngle3))
    xend3= xend - ps33*L2 * np.cos(np.radians(-0.6*CirAngle3))
    yend3 = yend + ps33*L2 * np.sin(np.radians(-0.6*CirAngle3))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps33")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="green",tag="ps33")

    xend = orgX-radius3*(1-np.cos(np.radians(0.4*CirAngle3)))
    yend = orgY+radius3* np.sin(np.radians(0.4*CirAngle3))
    xend2= xend - L2 * np.cos(np.radians(-0.4*CirAngle3))
    yend2 = yend + L2 * np.sin(np.radians(-0.4*CirAngle3))
    xend3= xend - ps34*L2 * np.cos(np.radians(-0.4*CirAngle3))
    yend3 = yend + ps34*L2 * np.sin(np.radians(-0.4*CirAngle3))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps34")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="green",tag="ps34")


    xst = orgX
    yst = orgY-radius4
    xend = orgX-radius4*np.sin(np.radians(CirAngle4))
    yend = orgY-radius4* (1-np.cos(np.radians(CirAngle4)))
    xend2= xend + L2 * np.sin(np.radians(CirAngle4))
    yend2 = yend - L2 * np.cos(np.radians(CirAngle4))
    xend3= xend + ps41*L2 * np.sin(np.radians(CirAngle4))
    yend3 = yend - ps41*L2 * np.cos(np.radians(CirAngle4))
    #canvas.create_line(xst, yst, xend, yend, width=4,fill="yellow",tag="ps41")
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps41")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="yellow",tag="ps41")
    
    xend = orgX-radius4*np.sin(np.radians(0.8*CirAngle4))
    yend = orgY-radius4* (1-np.cos(np.radians(0.8*CirAngle4)))
    xend2= xend + L2 * np.sin(np.radians(0.8*CirAngle4))
    yend2 = yend - L2 * np.cos(np.radians(0.8*CirAngle4))
    xend3= xend + ps42*L2 * np.sin(np.radians(0.8*CirAngle4))
    yend3 = yend - ps42*L2 * np.cos(np.radians(0.8*CirAngle4))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps42")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="yellow",tag="ps42")
    
    xend = orgX-radius4*np.sin(np.radians(0.6*CirAngle4))
    yend = orgY-radius4* (1-np.cos(np.radians(0.6*CirAngle4)))
    xend2= xend + L2 * np.sin(np.radians(0.6*CirAngle4))
    yend2 = yend - L2 * np.cos(np.radians(0.6*CirAngle4))
    xend3= xend + ps43*L2 * np.sin(np.radians(0.6*CirAngle4))
    yend3 = yend - ps43*L2 * np.cos(np.radians(0.6*CirAngle4))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps43")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="yellow",tag="ps43")

    xend = orgX-radius4*np.sin(np.radians(0.4*CirAngle4))
    yend = orgY-radius4* (1-np.cos(np.radians(0.4*CirAngle4)))
    xend2= xend + L2 * np.sin(np.radians(0.4*CirAngle4))
    yend2 = yend - L2 * np.cos(np.radians(0.4*CirAngle4))
    xend3= xend + ps44*L2 * np.sin(np.radians(0.4*CirAngle4))
    yend3 = yend - ps44*L2 * np.cos(np.radians(0.4*CirAngle4))
    canvas.create_line(xend, yend, xend2, yend2, width=1,fill="white",tag="ps44")
    canvas.create_line(xend, yend, xend3, yend3, width=4,fill="yellow",tag="ps44")
    
