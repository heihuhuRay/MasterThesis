global alpha_sup_kneePitch, alpha_unsup_kneePitch, alpha_sup_HipPitch, alpha_unsup_HipPitch, alpha_sup_AnkelPitch, alpha_unsup_AnkelPitch, alpha_sup_HipRoll, alpha_unsup_HipRoll, alpha_sup_AnkelRoll, alpha_unsup_AnkelRoll

global alpha_hip_ankle_pitch, alpha_knee_pitch


# alpha_hip_ankle_pitch = 0.02
# alpha_knee_pitch = 0.01
alpha_hip_ankle_pitch = 0
alpha_knee_pitch = 0

alpha_kneePitch = alpha_knee_pitch

alpha_HipPitch = alpha_hip_ankle_pitch

alpha_AnkelPitch = alpha_hip_ankle_pitch

# alpha_HipRoll = 0.022
# alpha_AnkelRoll = 0.032

# alpha_HipRoll = 0.03
# alpha_AnkelRoll = 0.06