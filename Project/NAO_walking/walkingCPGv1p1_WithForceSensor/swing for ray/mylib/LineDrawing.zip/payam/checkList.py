import math
# import os
import numpy as np
from chkInsideBoundaries import chkInsBnd
from chkReachingBoundaries import chkRchBnd
from rndmAngleGen import rndmAngleGen
from forwardKin import frwKin

"""
this function will select a random point, and will check the validity of a randomly selected point by:
1. being inside the envelope (workspace)
2. having enough distance from the boundary of the workspace

envelope = is the boundary of the workspace given as a vector.
"""
def chkPntValidity(envelope):
    point=[]
    theta_vec = []
    flag = 0
    # it will continue until a valid point with the satisfied conditions has been found
    while flag==0:
        Theta_SR, Theta_ER = rndmAngleGen();
        temp_theta = map(lambda x: x * math.pi / 180, [0, Theta_SR, 0, Theta_ER, -90])
        frw_temp = frwKin(temp_theta)
        Xarm_mat = frw_temp[0]
        Yarm_mat = frw_temp[1]
        point=np.array([Xarm_mat[2],Yarm_mat[2]])
        theta_vec = np.array([Theta_SR, Theta_ER])
        if (chkInsBnd(point,envelope)==1):
            if(chkRchBnd(point,envelope)==1):
                flag = 1
    return point, theta_vec