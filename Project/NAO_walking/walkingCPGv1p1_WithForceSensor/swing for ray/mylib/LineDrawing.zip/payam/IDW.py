import numpy as np
# IDW:
""""
           sigma w_i(vn).f(v_i)
f(vn)=  -------------------------
            sigma w_i(vn)

                 1
w_i(vn) = ---------------
                d(v_i,vn)
"""
# func_val = f(v_i)
# value_vec = v_i
# interpol_value = vn
# dist_type = type of distance (norm2, norm1, etc.)


def IDW (func_val, value_vec, interpol_value, dist_type):
    func_val = np.array(func_val)
    value_vec = np.array(value_vec)
    interpol_value = np.array(interpol_value)
    interpol_output = []
    if value_vec.shape[len(value_vec.shape)-1] != interpol_value.shape[len(interpol_value.shape)-1]:
        print 'size mismatch: both variables should have the same size (same space)'
        return None
    if value_vec.shape[0] != func_val.shape[0]:
        print 'size mismatch: the number of function samples should be equal to the number of its input'
        return None


    # interpol_output = np.empty((0, func_val.shape[len(func_val.shape) - 1]))
    if dist_type == 'norm2':
        temp_dist_vec = []
        # temp_dist_vec = np.empty((0, 1))
        for i in range (0, value_vec.shape[0]):
            temp_dist = np.dot((value_vec - interpol_value)[i,:], np.transpose(value_vec - interpol_value)[:,i])
            temp_dist_vec = np.append(temp_dist_vec, [temp_dist], axis=0)

        temp_dist_vec = np.sqrt(temp_dist_vec)
    else:
        print 'the name of the method of distance calculation is not valid'
        return None


    dist_vec = 1. / temp_dist_vec

    for i in range (0,func_val.shape[len(func_val.shape)-1]):
        interpol_output.append(np.dot(np.transpose(dist_vec),func_val[:,i]))
    interpol_output = np.array(np.multiply(interpol_output,1.0)/np.multiply(np.sum(dist_vec), 1.0))
        # interpol_output = np.append(interpol_output,[np.dot(np.transpose(dist_vec),func_val[:,i])],axis=len(func_val.shape)-1)
    return interpol_output

# # func_val=[[2,3,4],[4,5,6],[-1,2,4]]
# func_val=[[2,2],[-2,-2]]
# #
# # value_vec=[[7,6,7,8,9],[1,2,4,0,-1],[-2,2,2,4,0]]
#
# value_vec=[[10],[-10]]
# #
# interpol_value=[-5]
#
# # interpol_value=[1,1,1,1,1]
# #
# dist_type = 'norm2'
# #
# print IDW(func_val, value_vec, interpol_value, dist_type)

