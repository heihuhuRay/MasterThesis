import math
import numpy as np
"""
it will calculate the inverse kinematics of NAO's left arm with 2 DoF (Shoulder-Roll, and Elbow-Roll)

X, Y are the position of the end-effector, and the output will be theta of SR and ER

note: X and Y can be matrices
"""
def invKin(X, Y):
    X=np.array(X);
    Y=np.array(Y);
    if X.size==Y.size:
        Y = Y - 98;
        l_1 = np.sqrt(15 ** 2 + 105 ** 2);
        l_2 = np.sqrt((55.95 + 57.75) ** 2 + 12.31 ** 2);
        c2 = (X ** 2 + Y ** 2 - l_1 ** 2 - l_2 ** 2) / (2 * l_1 * l_2);
        s2 = -np.sqrt(1 - c2 ** 2);
        q_2 = np.arctan2(s2, c2);
        # % q_2 at the end should add 8 degree to it
        # % and subtract 6.1
        # % atan(12.31 / (55.95 + 57.75)) * 180 / pi hand offset z effect
        # % atan(15 / 105) * 180 / pi elbow offset y effect
        q_1 = np.arctan2(Y, X) - np.arctan2(l_2 * s2, l_1 + l_2 * c2);
        theta = np.array([q_1 - np.arctan(15.0 / 105.0), q_2 + np.arctan(15.0 / 105.0) - np.arctan(12.31 / (55.95 + 57.75))]);
        return theta
    else:
      print "size mismatch in two arrays of x and y"

# t=np.array([[4,5],[2,3],[6,6]]);
# a=np.array([[74.1025,203],[218.7,104.29],[98.7,203]]);
# b=np.array([[0.0,0],[98.7,98.7],[98.7,203]]);
# p= invKin(b[:,0],b[:,1])*180/math.pi;
# print p