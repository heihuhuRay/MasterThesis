import numpy as np
"""
saves data to a file (*.out) with the given data_name
"""
def save2file(data,data_name):

    try:
        np.savetxt(data_name+'.out', data)
        print "====================="
        print " %s has been saved to: \" %s.out\" "  % (data_name,data_name)
        print "To import it use: \"np.loadtxt('%s.out\')\"" % data_name
        print "====================="

    except:
        print "%s CAN NOT BE SAVED to: \"%s.out\"!!! " % (data_name,data_name)