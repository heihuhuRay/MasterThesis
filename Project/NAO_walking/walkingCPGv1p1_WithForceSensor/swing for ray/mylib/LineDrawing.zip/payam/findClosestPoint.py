import numpy as np
# import scipy.spatial.distance.cdist as cdist
"""
it will find the closest point from a series of point ("points") from a given point ("point")
and will return both the distance from and the index of the closest point from that series
"""
def closest_point(point, points):
    points = np.asarray(points)
    dist_all = np.sum((points - point)**2, axis=1)
    return np.argmin(dist_all), dist_all

# point=[0,0]
# points=np.array([[1,1],[2,3],[3,2],[0.7,0.6],[4,1]])
# print closest_point(point, points)[1][closest_point(point, points)[0]]