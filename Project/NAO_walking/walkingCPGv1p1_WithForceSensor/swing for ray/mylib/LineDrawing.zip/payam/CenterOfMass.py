import numpy as np
"""
it will find a center of mass of a shape whether it is concave or not.
envelope = the input should be a vector of the boundary of the shape. 
"""
def CoM(envelope):
    XY = np.array(envelope);
    Cx = 0;
    Cy = 0;

    Cx = Cx + np.dot(np.multiply(XY[0:-2,0],XY[0:-2,0]),np.append(XY[1:-2,1],XY[0,1]))
    Cx = Cx - np.dot(np.multiply(np.append(XY[1:-2, 0],XY[0,0]), np.append(XY[1:-2, 0],XY[0,0])),XY[0:-2,1])

    Cy = Cy - np.dot(np.multiply(XY[0:-2, 1], XY[0:-2, 1]), np.append(XY[1:-2, 0], XY[0, 0]))
    Cy = Cy + np.dot(np.multiply(np.append(XY[1:-2, 1], XY[0, 1]), np.append(XY[1:-2, 1], XY[0, 1])), XY[0:-2, 0])

    Cx = Cx - np.dot(np.multiply(XY[0:-2,0],np.append(XY[1:-2,0],XY[0,0])),np.subtract(XY[0:-2,1],np.append(XY[1:-2,1],XY[0,1])))

    Cy = Cy + np.dot(np.multiply(XY[0:-2,1],np.append(XY[1:-2,1],XY[0,1])),np.subtract(XY[0:-2,0],np.append(XY[1:-2,0],XY[0,0])))

    Cx = Cx / (6 * SignedArea(envelope))
    Cy = Cy / (6 * SignedArea(envelope))
    return Cx, Cy

def SignedArea(envelope):
    XY=np.array(envelope);
    area = (np.dot(XY[0:-2,0],np.append(XY[1:-2,1],XY[0,1]))-np.dot(XY[0:-2,1],np.append(XY[1:-2,0],XY[0,0])))/2;

    return area