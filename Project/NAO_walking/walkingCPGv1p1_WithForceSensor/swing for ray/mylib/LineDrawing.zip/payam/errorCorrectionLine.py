import numpy as np
from IDW import IDW
"""
this function tries to:
1. check if any of the performed action resulting in lines are in the acceptable range of error for any desired angle
2. for any desired angle that does not have a vector of alpha (accepted_alphas) an interpolation based on IDW will be used to converge to said desired angle.

angles_mat = matrix of angles of the drawn lines with the previously given motor program
alpha_mat = matrix of alpha (PF-layer) for the drawn lines
masked_angles = angles of the lines that should be drawn
all_data_angle = all of the angles of the lines drawn
all_data_alpha = all of the alphas for the all of the drawn lines
accepted_alphas = the accepted set of alphas for each of the desired angle (at the beginning it's an empty matrix of size 8 for 8 lines)
flag_vec_8lines = a vector of 1s and 0s, where the 1s shows that a satisfactory alpha for that angle has been found

"""
def errorCorrectionLine(angles_mat, alpha_mat, masked_angles, all_data_angle, all_data_alpha, accepted_alphas, flag_vec_8lines):
    # creates a vector of the size of the remaining desired angles, which can be set to 1 if any of the correspoding angles are found
    flag_success = np.zeros(len(masked_angles))
    # angles_mat = np.array(angles_mat)
    # alpha_mat = np.array(alpha_mat)
    # masked_angles = np.array(masked_angles)
    # all_data_angle = np.array(all_data_angle)
    # all_data_alpha = np.array(all_data_alpha)
    if (len(masked_angles) == len(angles_mat) == len(alpha_mat[:,0])):
        # alpha_mat_new = np.zeros([len(masked_angles),2])
        # creates an empty array for the new sets of alphas, which are interpolated by the IDW
        alpha_mat_new = []
        test_vec = np.ones(len(masked_angles))
        for i in range (0, len(masked_angles)):
            # subtracts the remaining desired angles from all the results of the previously performed action

            tempErrorVec = np.subtract(np.array(angles_mat),np.array(masked_angles[i]))

            # sets the error in range of -180 to 180, if it is above or below that
            tempErrorVec[tempErrorVec > 180] = tempErrorVec[tempErrorVec > 180] - 360
            tempErrorVec[tempErrorVec < -180] = (180 + tempErrorVec[tempErrorVec < -180]) + 180
            # checks if any of the performed action resulted in an acceptable error of less than 2.5 degree and only one istance of such has happened
            if (np.sum(test_vec[np.abs(tempErrorVec) < 2.5]) == 1):
                # the alpha vector of the corresponding acceptable error has been given to the same index of the desired angle, which has been satisfied
                # accepted_alphas[i,:] = alpha_mat[np.logical_and(flag_vec_8lines != np.ones(8), np.abs(tempErrorVec) < 2.5),:]

                accepted_alphas[np.nonzero(flag_vec_8lines != np.ones(8))[0][i], :] = alpha_mat[np.abs(tempErrorVec) < 2.5, :]
                # accepted_alphas[flag_vec_8lines != np.ones(8)][np.abs(tempErrorVec) < 2.5] = alpha_mat[i, :]
                # alpha_mat_new[np.abs(tempErrorVec) < 2.5] = alpha_mat[i,:]
                flag_success[i] = 1
                # flag_success[np.abs(tempErrorVec) < 2.5] = 1
                # flag_success[np.nonzero(test_vec[np.abs(tempErrorVec) < 2.5]) == 1] = 1
            # if more than one instance of result with acceptable error has occured, it will select the one with the lowest error
            elif (np.sum(test_vec[np.abs(tempErrorVec) < 2.5]) > 1):
                # the alpha vector of the corresponding acceptable error has been given to the same index of the desired angle, which has been satisfied
                # accepted_alphas[i,:] = alpha_mat[flag_vec_8lines != np.ones(8)][np.argmin(np.abs(tempErrorVec))]
                accepted_alphas[np.nonzero(flag_vec_8lines != np.ones(8))[0][i], :] = alpha_mat[np.argmin(np.abs(tempErrorVec))]
                # accepted_alphas[flag_vec_8lines != np.ones(8)][np.argmin(np.abs(tempErrorVec))] = alpha_mat[i, :]
                # alpha_mat_new[np.argmin(np.abs(tempErrorVec))] = alpha_mat[i,:]
                flag_success[i] = 1
                # flag_success[np.nonzero(test_vec[np.argmin(np.abs(tempErrorVec))]) == 1] = 1
            # if none of the performed actions are in the acceptable range a new set of alpha for that desired angle should be found
            else:
                # but it will check again for all of the performed action if there are close results to the desired angle and among those results,
                # the closest with positive and negative error will be selected, from which an IDW interpolation will generate a new set of alphas

                tempErrorVec_all = np.subtract(np.array(all_data_angle), np.array(masked_angles[i]))

                tempErrorVec_all[tempErrorVec_all > 180] = tempErrorVec_all[tempErrorVec_all > 180] - 360
                tempErrorVec_all[tempErrorVec_all < -180] = (180 + tempErrorVec_all[tempErrorVec_all < -180]) + 180
                # finding the closest angles to the desired angles: one with positive error and one with negative
                # maximum of the negative error and minimum of the positive error
                max_Neg = np.argmax(tempErrorVec_all[tempErrorVec_all < 0])
                min_Pos = np.argmin(tempErrorVec_all[tempErrorVec_all >= 0])
                # the corresponding alpha vectors of those two angles close the desired angles will be given to the IDW function
                # and the desired angle will be considered the interpolation point
                # all_data_alpha[np.array([max_Neg, min_Pos]), :]
                alpha_mat_new.append(np.array(IDW([all_data_alpha[tempErrorVec_all < 0][max_Neg], all_data_alpha[tempErrorVec_all >= 0][min_Pos]],
                                       [all_data_angle[tempErrorVec_all < 0][np.array([max_Neg])], all_data_angle[tempErrorVec_all >= 0][np.array([min_Pos])]],
                                       np.array([masked_angles[i]]),
                                       'norm2')))
                # alpha_mat_new[i] = IDW(all_data_alpha[np.array([max_Neg, min_Pos]),:], all_data_angle[np.array([max_Neg, min_Pos])], np.array([masked_angles[i]]), 'norm2')
        return alpha_mat_new, flag_success, accepted_alphas
    else:
        print 'size mismatch, please give input with the same number of columns'
        return None
