import matplotlib.pyplot as plt

import numpy as np
"""
it will draw the data (input1, input2) on a plot whose handler is given by h
"""
def figure_handle(h, input1, input2):
    x = np.array(input1)
    y = np.array(input2)
    ff = []
    hh = []
    # if (len(h) > 1):
    #
    #     for i in range (0, len(h)):
    #         # XX_YY = h[i].get_data()
    #         # x = np.append(XX_YY[0], x)
    #         # y = np.append(XX_YY[1], y)
    #         # plt.subplot()
    #         f = plt.plot(x, y, 'b', lw=3)
    #         plt.draw()
    #         ff.append(f)
    #         hh.append(h[i])
    # else:
    f = plt.plot(x, y, 'b', lw=3)
    plt.draw()
    ff.append(f)
    hh.append(h)
    return hh, ff