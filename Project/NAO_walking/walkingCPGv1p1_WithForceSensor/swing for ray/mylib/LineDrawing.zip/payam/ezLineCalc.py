import numpy as np
import math
"""
this function will calculate the angle, length and slope of a supposedly straight lines
X_vec and Y_vec are the input, where X_vec, Y_vec are the vectors of points on that line, however these can only include the starting and end point
all of the functions, including angle, length, would consider only the starting and end point of the given vector (it is assumed the data is for a straight line)
note: the input of this function can be a matrix, where the rows are the new lines, and it will return a vector of all angles of those lines
"""
def ezLineCalc(X_vec, Y_vec):
    X_vec = np.array(X_vec)
    Y_vec = np.array(Y_vec)
    if len(X_vec.shape) != len(Y_vec.shape):
        print 'size mismatch, both vectors (or matrices) should have the number of vectors'
        return None
    elif (len(X_vec.shape) > 1):
        for i in range (0, len(X_vec.shape)):
            if (X_vec.shape[i] != Y_vec.shape[i]):
                print 'dimension mismatch, check X and Y vector'
                return None
        beta_vec = []
        length_vec = []
        for i in range (0, X_vec.shape[0]):
            # creates arrays of the starting point (P_1) and end point (P_end)
            P_1 = np.array([-Y_vec[0], X_vec[0]])
            P_end = np.array([-Y_vec[-1], X_vec[-1]])
            beta_vec.append(find_angle(P_1, P_end))
            length_vec.append(find_length(P_1, P_end))

        return beta_vec, length_vec
    elif (len(X_vec.shape) == 1):

        P_1 = np.array([-Y_vec[0], X_vec[0]])
        P_end = np.array([-Y_vec[-1],X_vec[-1]])
        return find_angle(P_1, P_end), find_length(P_1, P_end)

    else:
        print 'empty vectors or size difference - not able to find the slope'
        return None

def find_slope(P_1, P_end):

    return (P_end[1] - P_1[1]) / (P_end[0] - P_1[0])

def find_angle(P_1, P_end):

    return np.arctan2(P_end[1] - P_1[1], P_end[0] - P_1[0]) * 180 / math.pi

def find_length(P_1, P_end):

    return np.sqrt(np.dot((P_1-P_end),(P_1-P_end)))