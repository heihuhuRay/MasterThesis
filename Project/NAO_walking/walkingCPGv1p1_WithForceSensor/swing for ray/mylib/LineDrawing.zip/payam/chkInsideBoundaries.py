import numpy as np
import matplotlib.path as mpltPath
"""
it will check if a point ("point") is inside an area, whose boundaries are given by a vector (envelope)
"""
def chkInsBnd(point,envelope):
    path = mpltPath.Path(envelope)
    inside_flag = path.contains_points([point])
    return int(inside_flag[0])