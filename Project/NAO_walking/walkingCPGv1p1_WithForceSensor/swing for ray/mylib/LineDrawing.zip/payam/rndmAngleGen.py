import random
"""
it will generate random values inside the limits of ShoulderRoll and ELbowRoll of NAO's left arm
"""

def rndmAngleGen():

    LSR_range = [0, 76];
    LER_range = [-88, 0];

    d_LSR=max(LSR_range)-min(LSR_range);
    d_LER=max(LER_range)-min(LER_range);

    Theta_SR=random.random()*d_LSR+min(LSR_range);
    Theta_ER=random.random()*d_LER+min(LER_range);

    return Theta_SR, Theta_ER