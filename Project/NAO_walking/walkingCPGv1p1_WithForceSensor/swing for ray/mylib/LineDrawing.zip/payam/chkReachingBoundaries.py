from findClosestPoint import closest_point
"""
checks if a point ("point") has a distance from the boundaries of a closed area (envelope)
the distance should be more than 10mm.

note: envelope here is assumed to be a vector of the boundary of a closed area, but it can be any series of data (not necessarily closed) 
"""
def chkRchBnd(point,envelope):
    return int(closest_point(point, envelope)[1][closest_point(point, envelope)[0]] >= 10.0) #10mm distance from boundary
# point=[0,0];
# print chkRchBnd(point)